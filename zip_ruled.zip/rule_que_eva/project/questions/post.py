import cv2
import mediapipe as mp
import numpy as np
import json
from datetime import datetime

# ======================= Mediapipe Setup =======================
mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose


# ======================= Age-based thresholds =======================
def get_thresholds(age):
    if age <= 21:  # strict for young
        return {"forward_lean": 8, "backward_lean": 8, "shoulder_tilt": 5}
    elif age <= 40:  # medium for adults
        return {"forward_lean": 12, "backward_lean": 12, "shoulder_tilt": 8}
    else:  # relaxed for older adults
        return {"forward_lean": 15, "backward_lean": 15, "shoulder_tilt": 10}


# ======================= Angle Calculation =======================
def calculate_angle(a, b, c):
    """Calculate angle between three points"""
    a = np.array(a)  # first
    b = np.array(b)  # mid
    c = np.array(c)  # end

    radians = np.arctan2(c[1] - b[1], c[0] - b[0]) - np.arctan2(
        a[1] - b[1], a[0] - b[0]
    )
    angle = np.abs(radians * 180.0 / np.pi)

    if angle > 180.0:
        angle = 360 - angle
    return angle


# ======================= Posture Classification =======================
def classify_posture(landmarks, thresholds):
    # Get coordinates (normalized → pixel space not needed for angles)
    nose = [landmarks[mp_pose.PoseLandmark.NOSE.value].x,
            landmarks[mp_pose.PoseLandmark.NOSE.value].y]
    shoulder = [landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
                landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
    hip = [landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].x,
           landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].y]
    shoulder_r = [landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].x,
                  landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].y]

    # Angles
    back_angle = calculate_angle(nose, shoulder, hip)  # forward/backward lean
    shoulder_tilt = abs(shoulder[1] - shoulder_r[1]) * 100  # difference in height

    status = "Good Posture"
    score = 100

    if back_angle > (90 + thresholds["forward_lean"]):
        status = "Leaning Forward"
        score -= 30
    elif back_angle < (90 - thresholds["backward_lean"]):
        status = "Leaning Backward"
        score -= 30
    elif shoulder_tilt > thresholds["shoulder_tilt"]:
        status = "Shoulder Tilt"
        score -= 20

    return status, max(score, 0)


# ======================= JSON Logging =======================
def save_session_log(session_data, filename="posture_sessions.json"):
    with open(filename, "a") as f:
        json.dump(session_data, f)
        f.write("\n")  # keep each session in a new line


# ======================= Main Program =======================
def main():
    # Ask for age
    user_age = int(input("Enter your age: "))
    thresholds = get_thresholds(user_age)

    # Initialize camera
    cap = cv2.VideoCapture(0)

    # Session stats
    session_start = datetime.now()
    posture_scores = []
    alerts = []

    with mp_pose.Pose(min_detection_confidence=0.5,
                      min_tracking_confidence=0.5) as pose:
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            # Convert BGR → RGB
            image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            image.flags.writeable = False

            # Make detection
            results = pose.process(image)

            # Convert back to BGR
            image.flags.writeable = True
            image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

            try:
                landmarks = results.pose_landmarks.landmark
                status, score = classify_posture(landmarks, thresholds)
                posture_scores.append(score)

                if status != "Good Posture":
                    alerts.append(status)

                # Display status
                cv2.putText(image, f"Posture: {status}", (50, 50),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                cv2.putText(image, f"Score: {score}", (50, 100),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)

                # Draw landmarks
                mp_drawing.draw_landmarks(image, results.pose_landmarks,
                                          mp_pose.POSE_CONNECTIONS)

            except:
                pass

            cv2.imshow("Posture Monitor", image)

            if cv2.waitKey(10) & 0xFF == ord("q"):  # quit with q
                break

    cap.release()
    cv2.destroyAllWindows()

    # Session end and logging
    session_end = datetime.now()
    duration = (session_end - session_start).seconds // 60
    avg_score = int(sum(posture_scores) / len(posture_scores)) if posture_scores else 0

    session_data = {
        "session_id": int(session_start.timestamp()),
        "age": user_age,
        "start_time": str(session_start),
        "end_time": str(session_end),
        "duration_minutes": duration,
        "average_posture_score": avg_score,
        "alerts_triggered": len(alerts),
        "issues_detected": list(set(alerts)),
    }

    save_session_log(session_data)
    print("Session saved:", session_data)


if __name__ == "__main__":
    main()