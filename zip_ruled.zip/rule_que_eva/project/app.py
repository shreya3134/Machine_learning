from flask import Flask, render_template, request, redirect, session, jsonify, url_for
import os, json, random
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer, util

app = Flask(__name__)
app.secret_key = "supersecretkey"

# Load environment variables
load_dotenv()

# Files
USERS_FILE = "users.json"
ATTEMPTS_FILE = "attempts.jsonl"
REFERENCE_FILE = "reference_answers.json"
TOPIC_FOLDER = "questions"

# Load BERT model
model = SentenceTransformer('all-MiniLM-L6-v2')


# ---------------- Helper Functions ----------------
def safe_load_users():
    if not os.path.exists(USERS_FILE):
        return {}
    try:
        with open(USERS_FILE, "r", encoding="utf-8") as f:
            content = f.read().strip()
            return json.loads(content) if content else {}
    except json.JSONDecodeError:
        return {}


def save_users(users):
    with open(USERS_FILE, "w", encoding="utf-8") as f:
        json.dump(users, f, indent=4)


def load_rule_questions(topic="Python", difficulty="Basic"):
    filename = f"{topic}_{difficulty}.txt"
    file_path = os.path.join(TOPIC_FOLDER, filename)
    if not os.path.exists(file_path):
        return []
    with open(file_path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]


def load_reference_answers():
    if not os.path.exists(REFERENCE_FILE):
        return {}
    try:
        with open(REFERENCE_FILE, "r", encoding="utf-8") as f:
            content = f.read().strip()
            return json.loads(content) if content else {}
    except json.JSONDecodeError:
        return {}


def evaluate_answer_bert(user_answer, correct_answer):
    if not user_answer or not correct_answer:
        return {"score": 0, "feedback": "No valid answers to compare."}

    emb1 = model.encode(user_answer, convert_to_tensor=True)
    emb2 = model.encode(correct_answer, convert_to_tensor=True)
    similarity = util.pytorch_cos_sim(emb1, emb2).item()

    if similarity > 0.85:
        feedback = "✅ Excellent and detailed answer!"
    elif similarity > 0.65:
        feedback = "⚠️ Fair answer, but can be improved."
    else:
        feedback = "❌ Not correct. Please review the concept again."

    return {"score": round(similarity * 100, 2), "feedback": feedback}


def get_topics_and_difficulties():
    topics = {}
    if not os.path.exists(TOPIC_FOLDER):
        return topics
    files = [f for f in os.listdir(TOPIC_FOLDER) if os.path.isfile(os.path.join(TOPIC_FOLDER, f))]
    for f in files:
        if "_" in f and f.endswith(".txt"):
            parts = f.replace(".txt", "").split("_")
            topic = parts[0]
            difficulty = parts[1] if len(parts) > 1 else "Basic"
            topics.setdefault(topic, []).append(difficulty)
    return topics


def get_next_attempt_number(username):
    """Return next attempt number for username by scanning attempts file."""
    next_attempt = 1
    if os.path.exists(ATTEMPTS_FILE):
        try:
            with open(ATTEMPTS_FILE, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        rec = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if rec.get("user") == username:
                        att = rec.get("attempt", 1)
                        if isinstance(att, int) and att >= next_attempt:
                            next_attempt = att + 1
        except Exception:
            pass
    return next_attempt


# ---------------- Routes ----------------
@app.route("/")
def home():
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "").strip()
        if not username or not email or not password:
            return "All fields are required!"
        users = safe_load_users()
        if username in users:
            return "Username already exists!"
        users[username] = {"password": password, "email": email, "scores": {}}
        save_users(users)
        session["user"] = username
        return redirect(url_for("select"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        if not username or not password:
            return "Both username and password are required!"
        users = safe_load_users()
        if username in users and users[username]["password"] == password:
            session["user"] = username
            return redirect(url_for("select"))
        else:
            return "Invalid username or password!"
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/select", methods=["GET", "POST"])
def select():
    if "user" not in session:
        return redirect(url_for("login"))
    topics = get_topics_and_difficulties()
    if request.method == "POST":
        topic = request.form.get("topic")
        difficulty = request.form.get("difficulty")
        if not topic or not difficulty:
            return "Please select both topic and difficulty!"
        session["topic"] = topic
        session["difficulty"] = difficulty
        return redirect(url_for("index"))
    return render_template("select.html", topics=topics)


@app.route("/index")
def index():
    if "user" not in session:
        return redirect(url_for("login"))
    if "topic" not in session or "difficulty" not in session:
        return redirect(url_for("select"))

    topic = session["topic"]
    difficulty = session["difficulty"]
    total_questions = len(load_rule_questions(topic, difficulty))

    if "attempt_number" not in session:
        session["attempt_number"] = get_next_attempt_number(session["user"])

    return render_template(
        "index.html",
        username=session["user"],
        topic=topic,
        difficulty=difficulty,
        total_questions=total_questions,
        current_attempt=session["attempt_number"]
    )


@app.route("/get_question", methods=["POST"])
def get_question():
    data = request.json or {}
    q_index = data.get("index", None)
    q_type = data.get("type", "rule")
    topic = session.get("topic", "Python")
    difficulty = session.get("difficulty", "Basic")

    questions = load_rule_questions(topic, difficulty)
    if not questions:
        return jsonify({"question": f"No questions found for {topic} ({difficulty})."})

    if q_index is not None:
        try:
            q_index = int(q_index)
            if 0 <= q_index < len(questions):
                return jsonify({"question": questions[q_index]})
        except (ValueError, TypeError):
            pass

    if q_type == "rule":
        return jsonify({"question": random.choice(questions)})
    else:
        return jsonify({"question": "AI Question not implemented."})


@app.route("/submit_answer", methods=["POST"])
def submit_answer():
    data = request.get_json()
    if not data:
        return jsonify({"status": "error", "message": "No JSON received!"})

    question = data.get("question")
    user_answer = data.get("answer")
    username = session.get("user")
    topic = session.get("topic", "General")
    attempt_no = session.get("attempt_number", 1)

    if not (question and user_answer and username):
        return jsonify({"status": "error", "message": "Missing question, answer, or user."})

    reference_answers = load_reference_answers()
    correct_answer = reference_answers.get(question)
    if not correct_answer:
        return jsonify({
            "status": "error",
            "message": f"No reference answer available for: {question}"
        })

    result = evaluate_answer_bert(user_answer, correct_answer)

    attempt = {
        "user": username,
        "topic": topic,
        "attempt": attempt_no,
        "question": question,
        "answer": user_answer,
        "score": result["score"],
        "feedback": result["feedback"]
    }
    with open(ATTEMPTS_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(attempt) + "\n")

    users = safe_load_users()
    if username not in users:
        users[username] = {"password": "", "email": "", "scores": {}}
    if "scores" not in users[username]:
        users[username]["scores"] = {}
    if topic not in users[username]["scores"]:
        users[username]["scores"][topic] = {}
    users[username]["scores"][topic][question] = result["score"]
    save_users(users)

    return jsonify({
        "status": "saved",
        "score": result["score"],
        "feedback": result["feedback"]
    })


@app.route("/submit_test", methods=["POST"])
def submit_test():
    username = session.get("user")
    topic = session.get("topic")
    difficulty = session.get("difficulty")
    if not (username and topic):
        return jsonify({"status": "error", "message": "Session expired."})

    users = safe_load_users()
    questions = load_rule_questions(topic, difficulty)
    if username not in users:
        users[username] = {"password": "", "email": "", "scores": {}}
    if "scores" not in users[username]:
        users[username]["scores"] = {}
    if topic not in users[username]["scores"]:
        users[username]["scores"][topic] = {}

    user_scores = users[username]["scores"][topic]
    for q in questions:
        if q not in user_scores:
            user_scores[q] = 0

    total_score = sum(user_scores.values())
    max_score = len(questions) * 100
    percentage = round(total_score / max_score * 100, 2) if max_score > 0 else 0

    users[username]["scores"][topic]["total_score"] = percentage
    save_users(users)

    session["total_score"] = percentage
    return jsonify({
        "status": "submitted",
        "total_score": percentage,
        "redirect_url": url_for("score_evaluation")
    })


# ✅ FINAL FIXED SCORE EVALUATION ROUTE
@app.route("/score_evaluation")
def score_evaluation():
    if "user" not in session:
        return redirect(url_for("login"))

    username = session["user"]
    topic = session.get("topic", "General")
    difficulty = session.get("difficulty", "Basic")
    attempt_no = session.get("attempt_number", 1)

    reference_answers = load_reference_answers()
    questions = load_rule_questions(topic, difficulty)

    # Read attempts from JSONL file
    attempts_data = []
    if os.path.exists(ATTEMPTS_FILE):
        with open(ATTEMPTS_FILE, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    record = json.loads(line)
                    if record.get("user") == username:
                        attempts_data.append(record)
                except json.JSONDecodeError:
                    continue

    # Compute stats
    total_attempts = len(set(a.get("attempt", 1) for a in attempts_data))
    total_score = sum(a.get("score", 0) for a in attempts_data)
    avg_score = round(total_score / len(attempts_data), 2) if attempts_data else 0

    report = []
    total_for_attempt = 0
    count_questions = 0

    for q in questions:
        user_answer = ""
        feedback = ""
        score = 0
        missed_keywords = []

        for a in attempts_data:
            if (a.get("question") == q and a.get("attempt") == attempt_no):
                user_answer = a.get("answer", "")
                feedback = a.get("feedback", "")
                score = a.get("score", 0)
                break

        correct_answer = reference_answers.get(q, "")
        if correct_answer:
            correct_words = set(correct_answer.lower().split())
            user_words = set(user_answer.lower().split())
            missed_keywords = sorted(list(correct_words - user_words))

        total_for_attempt += score
        count_questions += 1

        report.append({
            "question": q,
            "user_answer": user_answer,
            "correct_answer": correct_answer,
            "score": score,
            "feedback": feedback,
            "missed_keywords": missed_keywords
        })

    attempt_percentage = round(total_for_attempt / (count_questions * 100) * 100, 2) if count_questions > 0 else 0

    return render_template(
        "score_evaluation.jinja2",
        username=username,
        topic=topic,
        difficulty=difficulty,
        total_score=attempt_percentage,
        total_attempts=total_attempts,
        avg_score=avg_score,
        report=report,
        attempt_no=attempt_no
    )


# ---------------- Main ----------------
if __name__ == "__main__":
    app.run(debug=True)
