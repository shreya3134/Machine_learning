// ===============================
// Global Variables
// ===============================
const totalQuestions = 50;
let questions = Array(totalQuestions).fill(null);
let questionStatus = Array(totalQuestions).fill("not-answered");
let questionScores = Array(totalQuestions).fill(0);
let answersGiven = Array(totalQuestions).fill("");
let currentIndex = 0;
let timer;
let timeLeft = 60;
let chart;
let activityChart; // 🆕 new chart for tracking actions
let actionHistory = []; // 🆕 store history of actions

// ===============================
// DOM Elements
// ===============================
const questionBox = document.getElementById("question");
const answerBox = document.getElementById("answer");
const attemptedList = document.getElementById("attemptedQuestions");
const generateBtn = document.getElementById("generateBtn");
const nextBtn = document.getElementById("nextBtn");
const prevBtn = document.getElementById("prevBtn");
const holdBtn = document.getElementById("holdBtn");
const submitBtn = document.getElementById("submitBtn");
const speakBtn = document.getElementById("speakQuestionBtn");
const recordBtn = document.getElementById("recordAnswerBtn");
const scoreDisplay = document.getElementById("scoreDisplay");

// Create dynamic feedback elements
const feedbackDisplay = document.createElement("div");
feedbackDisplay.id = "scoreText";
scoreDisplay.after(feedbackDisplay);
const totalScoreDisplay = document.createElement("div");
totalScoreDisplay.id = "totalScoreDisplay";
feedbackDisplay.after(totalScoreDisplay);

// 🆕 Create Submit Test Button dynamically
const submitTestBtn = document.createElement("button");
submitTestBtn.id = "submitTestBtn";
submitTestBtn.innerText = "✅ Submit Test";
submitTestBtn.classList.add("submit-test");
totalScoreDisplay.after(submitTestBtn);

// ===============================
// Chart Initialization
// ===============================
function initChart() {
    const ctx = document.getElementById("progressChart");
    chart = new Chart(ctx, {
        type: "pie",
        data: {
            labels: ["Answered", "Not Answered", "Hold"],
            datasets: [{
                data: [0, totalQuestions, 0],
                backgroundColor: ["#28a745", "#007bff", "#ff4d4d"]
            }]
        },
        options: { responsive: true }
    });

    // 🆕 Add second chart for question actions
    const activityCanvas = document.createElement("canvas");
    activityCanvas.id = "activityChart";
    ctx.parentNode.appendChild(activityCanvas);

    activityChart = new Chart(activityCanvas, {
        type: "line",
        data: {
            labels: [],
            datasets: [{
                label: "Question Actions",
                data: [],
                borderWidth: 3,
                tension: 0.3,
                pointRadius: 6,
                pointBackgroundColor: [],
                borderColor: "#666",
                fill: false
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                x: { title: { display: true, text: "Action Sequence" } },
                y: {
                    title: { display: true, text: "Question Index" },
                    ticks: { stepSize: 1, beginAtZero: true, precision: 0 }
                }
            }
        }
    });
}

function updateChart() {
    const answered = questionStatus.filter(s => s === "answered").length;
    const hold = questionStatus.filter(s => s === "hold").length;
    const notAnswered = totalQuestions - answered - hold;
    chart.data.datasets[0].data = [answered, notAnswered, hold];
    chart.update();
}

// ===============================
// 🆕 Activity Chart Logger
// ===============================
function logAction(actionType) {
    const colorMap = {
        "Next": "green",
        "Previous": "red",
        "Hold": "blue",
        "Generate": "orange"
    };

    actionHistory.push({
        label: `${actionType} (${currentIndex + 1})`,
        index: currentIndex + 1,
        color: colorMap[actionType] || "gray"
    });

    // Limit data length
    if (actionHistory.length > 30) actionHistory.shift();

    // Update chart
    activityChart.data.labels = actionHistory.map(a => a.label);
    activityChart.data.datasets[0].data = actionHistory.map(a => a.index);
    activityChart.data.datasets[0].pointBackgroundColor = actionHistory.map(a => a.color);
    activityChart.update();
}

// ===============================
// Timer
// ===============================
function startTimer() {
    clearInterval(timer);
    timeLeft = 60;
    document.getElementById("timer").textContent = `⏱ Time Left: ${timeLeft}s`;
    timer = setInterval(() => {
        timeLeft--;
        document.getElementById("timer").textContent = `⏱ Time Left: ${timeLeft}s`;
        if (timeLeft <= 0) {
            clearInterval(timer);
            alert("⏰ Time's up! Moving to next question.");
            nextQuestion();
        }
    }, 1000);
}

// ===============================
// Question Navigation
// ===============================
function fetchQuestion(index) {
    currentIndex = index;
    if (!questions[index]) {
        fetch("/get_question", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ type: "rule" })
        })
        .then(res => res.json())
        .then(data => {
            questions[index] = data.question;
            displayQuestion(index);
        })
        .catch(err => {
            console.error("Error fetching question:", err);
            questionBox.textContent = "⚠️ Error fetching question!";
        });
    } else {
        displayQuestion(index);
    }
}

function displayQuestion(index) {
    questionBox.textContent = questions[index];
    answerBox.value = answersGiven[index] || "";
    updateGridStatus();
    startTimer();
}

function nextQuestion() {
    const nextIndex = Math.min(currentIndex + 1, totalQuestions - 1);
    fetchQuestion(nextIndex);
    logAction("Next"); // 🆕 log
}

function prevQuestion() {
    const prevIndex = Math.max(currentIndex - 1, 0);
    fetchQuestion(prevIndex);
    logAction("Previous"); // 🆕 log
}

// ===============================
// Question Tracker Grid
// ===============================
function renderGrid() {
    const grid = document.getElementById("questionGrid");
    grid.innerHTML = "";
    for (let i = 0; i < totalQuestions; i++) {
        const div = document.createElement("div");
        div.classList.add("grid-item", questionStatus[i]);
        if (i === currentIndex) div.classList.add("current");
        div.textContent = i + 1;
        div.addEventListener("click", () => fetchQuestion(i));
        grid.appendChild(div);
    }
}

function updateGridStatus() {
    const grid = document.getElementById("questionGrid").children;
    for (let i = 0; i < grid.length; i++) {
        grid[i].className = "grid-item";
        grid[i].classList.add(questionStatus[i]);
        if (i === currentIndex) grid[i].classList.add("current");
    }
}

// ===============================
// Buttons
// ===============================
generateBtn.addEventListener("click", () => {
    fetchQuestion(currentIndex);
    logAction("Generate"); // 🆕 log
});
nextBtn.addEventListener("click", nextQuestion);
prevBtn.addEventListener("click", prevQuestion);
holdBtn.addEventListener("click", () => {
    questionStatus[currentIndex] = "hold";
    updateGridStatus();
    updateChart();
    logAction("Hold"); // 🆕 log
});

// ===============================
// Submit Answer & Evaluate
// ===============================
submitBtn.addEventListener("click", () => {
    const answer = answerBox.value.trim();
    const question = questionBox.textContent;

    if (!answer) {
        alert("Please type or speak your answer before submitting!");
        return;
    }

    fetch("/submit_answer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question, answer })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === "saved") {
            questionStatus[currentIndex] = "answered";
            questionScores[currentIndex] = data.score;
            answersGiven[currentIndex] = answer;

            attemptedList.innerHTML += `<li>${question} - Score: ${data.score}%</li>`;
            updateGridStatus();
            updateChart();

            feedbackDisplay.innerHTML = `
                💬 <b>Feedback:</b> ${data.feedback}<br>
                ⭐ <b>Score:</b> ${data.score}%
            `;
            updateTotalScore();

            const utterance = new SpeechSynthesisUtterance(data.feedback);
            utterance.lang = "en-US";
            window.speechSynthesis.speak(utterance);
        } else {
            feedbackDisplay.textContent = "❌ Error evaluating your answer.";
        }
    })
    .catch(err => {
        console.error("Error submitting answer:", err);
        feedbackDisplay.textContent = "⚠️ Network error while submitting answer.";
    });
});

// ===============================
// Total Score Calculation
// ===============================
function updateTotalScore() {
    let total = 0;
    for (let i = 0; i < totalQuestions; i++) {
        total += questionScores[i];
    }
    const totalPercentage = (total / (totalQuestions * 100)) * 100;
    totalScoreDisplay.innerHTML = `🏆 <b>Total Score:</b> ${totalPercentage.toFixed(2)}%`;
}

// ===============================
// Speech Features
// ===============================
speakBtn.addEventListener("click", () => {
    const questionText = questionBox.innerText.trim();
    if (!questionText) return alert("No question to read!");
    const utterance = new SpeechSynthesisUtterance(questionText);
    utterance.lang = "en-US";
    window.speechSynthesis.speak(utterance);
});

let recognition;
if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
    recognition.onresult = (event) => {
        answerBox.value += event.results[0][0].transcript + " ";
    };
    recognition.onerror = (event) => console.error("Speech recognition error:", event.error);
} else {
    alert("Speech recognition not supported in this browser.");
}

// ===============================
// Question Navigation (UPDATED)
// ===============================
let consecutiveSkips = 0; // 🆕 Track unattempted skips

function nextQuestion() {
    // Check if current question is unattempted
    const currentAnswer = answerBox.value.trim();
    if (!currentAnswer && questionStatus[currentIndex] === "not-answered") {
        consecutiveSkips++;
    } else {
        consecutiveSkips = 0; // reset if answered or held
    }

    // 🆕 Show warning if skipped twice without attempt
    if (consecutiveSkips >= 2) {
        alert("⚠️ You skipped two questions in a row without attempting — your score may be affected!");
        consecutiveSkips = 0; // reset after warning
    }

    const nextIndex = Math.min(currentIndex + 1, totalQuestions - 1);
    fetchQuestion(nextIndex);
    logAction("Next"); // log user navigation
}


recordBtn.addEventListener("click", () => {
    if (recognition) {
        recognition.start();
        alert("🎤 Listening... Speak your answer now!");
    }
});

// ===============================
// 🟩 Submit Entire Test Feature
// ===============================
submitTestBtn.addEventListener("click", () => {
    if (!confirm("⚠️ Are you sure you want to submit your test? Unanswered questions will be scored as 0.")) return;

    clearInterval(timer);

    const submissionData = questions.map((q, i) => ({
        question: q,
        answer: answersGiven[i] || "",
        score: questionScores[i] || 0,
        status: questionStatus[i]
    }));

    fetch("/submit_test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ results: submissionData })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === "submitted") {
            alert(`✅ Test submitted successfully! Redirecting to evaluation...`);
            window.location.href = data.redirect_url;
        } else {
            alert("❌ Failed to submit test!");
        }
    })
    .catch(err => {
        console.error("Error submitting test:", err);
        alert("⚠️ Network error during submission.");
    });
});

// ===============================
// Initialize
// ===============================
renderGrid();
initChart();
fetchQuestion(currentIndex);
