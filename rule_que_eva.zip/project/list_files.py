import os

# Folder path
folder_path = "questions"  # replace with your folder path

# Check if folder exists
if not os.path.exists(folder_path):
    print(f"Folder '{folder_path}' does not exist!")
else:
    files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
    if files:
        print("Files in folder:")
        for file in files:
            print(file)
    else:
        print("No files found in the folder.")
