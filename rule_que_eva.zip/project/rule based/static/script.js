document.addEventListener("DOMContentLoaded", function () {
    // ======= DOM Elements =======
    const questionBox = document.getElementById("question");
    const answerBox = document.getElementById("answer");
    const attemptedList = document.getElementById("attemptedQuestions");
    const generateBtn = document.getElementById("generateBtn");
    const nextBtn = document.getElementById("nextBtn");
    const prevBtn = document.getElementById("prevBtn");
    const holdBtn = document.getElementById("holdBtn");
    const submitBtn = document.getElementById("submitBtn");
    const timerDisplay = document.getElementById("timer");

    // ======= Variables =======
    const totalQuestions = 40;
    let questions = Array(totalQuestions).fill(null); // store fetched questions
    let questionStatus = Array(totalQuestions).fill("not-answered"); // default status
    let currentIndex = 0;
    let currentQuestion = "";
    let heldQuestions = [];
    let nextClickCount = 0;
    let lastNextClickTime = 0;
    let timer = null;
    let timeLeft = 60;

    // ======= Chart Setup =======
    const ctx = document.getElementById("progressChart").getContext("2d");
    const chartData = {
        labels: ["Generated", "Answered", "On Hold"],
        datasets: [{
            label: "Question Progress",
            data: [0, 0, 0],
            backgroundColor: ["#007bff", "#28a745", "#ff4d4d"]
        }]
    };
    const progressChart = new Chart(ctx, {
        type: "bar",
        data: chartData,
        options: {
            responsive: true,
            plugins: { legend: { display: false }, tooltip: { enabled: true } },
            scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
        }
    });

    function updateChart(index, increment = 1) {
        chartData.datasets[0].data[index] += increment;
        progressChart.update();
    }

    // ======= Timer =======
    function startTimer() {
        clearInterval(timer);
        timeLeft = 60;
        timerDisplay.textContent = `⏱ Time Left: ${timeLeft}s`;
        submitBtn.disabled = false;

        timer = setInterval(() => {
            timeLeft--;
            timerDisplay.textContent = `⏱ Time Left: ${timeLeft}s`;
            if (timeLeft <= 0) {
                clearInterval(timer);
                timerDisplay.textContent = "⏰ Time’s up!";
                submitBtn.disabled = true;
                alert("⏰ Time’s up for this question!");
            }
        }, 1000);
    }

    // ======= Fetch Question =======
    function fetchQuestion() {
        // Load from questions[] if already fetched
        if (questions[currentIndex]) {
            displayQuestion(currentIndex);
            return;
        }

        // Otherwise, fetch from server
        fetch("/get_question", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ type: "rule", index: currentIndex })
        })
        .then(res => res.json())
        .then(data => {
            questions[currentIndex] = data.question;
            displayQuestion(currentIndex);
            if (questionStatus[currentIndex] === "not-answered") updateChart(0); // Generated++
        })
        .catch(err => {
            console.error("Error fetching question:", err);
            questionBox.textContent = "⚠️ Error fetching question!";
        });
    }

    function displayQuestion(index) {
        currentIndex = index;
        currentQuestion = questions[index];
        questionBox.textContent = currentQuestion;

        // Load previously entered answer if you store answers
        answerBox.value = ""; 

        startTimer();
        updateGridStatus();
    }

    // ======= Button Listeners =======
    generateBtn.addEventListener("click", () => {
        nextClickCount = 0;
        fetchQuestion();
    });

    nextBtn.addEventListener("click", () => {
        const now = Date.now();
        const diff = now - lastNextClickTime;
        lastNextClickTime = now;

        if (diff < 2000) nextClickCount++;
        else nextClickCount = 0;

        if (nextClickCount >= 3) {
            alert("⚠️ Slow down! Try answering before skipping multiple questions.");
            nextClickCount = 0;
            return;
        }

        // Mark skipped if not answered
        if (questionStatus[currentIndex] !== "answered" && questionStatus[currentIndex] !== "hold") {
            questionStatus[currentIndex] = "not-answered";
        }

        currentIndex = Math.min(currentIndex + 1, totalQuestions - 1);
        fetchQuestion();
    });

    prevBtn.addEventListener("click", () => {
        currentIndex = Math.max(currentIndex - 1, 0);
        fetchQuestion(); // loads same question if skipped
    });

    holdBtn.addEventListener("click", () => {
        if (!currentQuestion) return;
        if (!heldQuestions.includes(currentQuestion)) heldQuestions.push(currentQuestion);
        questionStatus[currentIndex] = "hold";
        updateChart(2); // On Hold++
        updateGridStatus();
        alert("✅ Question held for later!");
    });

    submitBtn.addEventListener("click", () => {
        const answer = answerBox.value.trim();
        if (!currentQuestion) return alert("⚠️ No question available!");
        if (!answer) return alert("✍️ Please type your answer before submitting!");

        fetch("/submit_answer", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ question: currentQuestion, answer: answer })
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === "saved") {
                const li = document.createElement("li");
                li.textContent = `Q: ${currentQuestion} | Your Answer: ${answer}`;
                attemptedList.appendChild(li);
                answerBox.value = "";
                clearInterval(timer);
                timerDisplay.textContent = "✅ Answer submitted!";
                questionStatus[currentIndex] = "answered";
                updateChart(1); // Answered++
                updateGridStatus();
                alert("✅ Answer submitted successfully!");
            } else {
                alert("❌ Error saving your answer!");
            }
        })
        .catch(err => {
            console.error("Error submitting answer:", err);
            alert("⚠️ Network error while submitting answer.");
        });
    });

    // ======= Grid Rendering =======
    function renderGrid() {
        const grid = document.getElementById("questionGrid");
        grid.innerHTML = "";
        for (let i = 0; i < totalQuestions; i++) {
            const div = document.createElement("div");
            div.classList.add("grid-item", questionStatus[i]);
            if (i === currentIndex) div.classList.add("current");
            div.textContent = i + 1;
            div.addEventListener("click", () => {
                currentIndex = i;
                fetchQuestion(); // loads same question if skipped or answered
            });
            grid.appendChild(div);
        }
    }

    function updateGridStatus() {
        const grid = document.getElementById("questionGrid").children;
        for (let i = 0; i < grid.length; i++) {
            grid[i].className = "grid-item"; // reset
            grid[i].classList.add(questionStatus[i]);
            if (i === currentIndex) grid[i].classList.add("current");
        }
    }

    // ======= Initial Render =======
    renderGrid();
});
