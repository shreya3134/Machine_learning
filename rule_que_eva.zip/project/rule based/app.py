from flask import Flask, render_template, request, redirect, session, jsonify, url_for
import random, os, json
from dotenv import load_dotenv
import openai

# ================= CONFIG =================
load_dotenv()
app = Flask(__name__)
app.secret_key = "supersecretkey"

openai.api_key = os.getenv("OPENAI_API_KEY")

ATTEMPTS_FILE = "attempts.jsonl"
USERS_FILE = "users.json"
TOPIC_FOLDER = "questions"

# ---------- Helper Functions --------------
def safe_load_users():
    if not os.path.exists(USERS_FILE):
        return {}
    try:
        with open(USERS_FILE, "r") as f:
            content = f.read().strip()
            return json.loads(content) if content else {}
    except json.JSONDecodeError:
        return {}

def save_users(users):
    with open(USERS_FILE, "w") as f:
        json.dump(users, f, indent=4)

def load_rule_questions(topic="Python", difficulty="Basic"):
    filename = f"{topic}_{difficulty}.txt"
    file_path = os.path.join(TOPIC_FOLDER, filename)
    if not os.path.exists(file_path):
        return []
    with open(file_path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

def get_ai_question(topic="Python"):
    prompt = f"Generate a single technical interview question about {topic}."
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=60,
            temperature=0.7
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"AI generation failed: {e}"

def get_topics_and_difficulties():
    topics = {}
    if not os.path.exists(TOPIC_FOLDER):
        return topics
    files = [f for f in os.listdir(TOPIC_FOLDER) if os.path.isfile(os.path.join(TOPIC_FOLDER, f))]
    for f in files:
        if "_" in f and f.endswith(".txt"):
            parts = f.replace(".txt", "").split("_")
            topic = parts[0]
            difficulty = parts[1] if len(parts) > 1 else "Basic"
            topics.setdefault(topic, []).append(difficulty)
    return topics

# ---------- Routes ----------------
@app.route("/", methods=["GET"])
def home():
    return redirect(url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "").strip()

        if not username or not email or not password:
            return "All fields are required!"

        users = safe_load_users()

        if username in users:
            return "Username already exists! Try another."

        users[username] = {"password": password, "email": email}
        save_users(users)

        session["user"] = username
        return redirect(url_for("select"))

    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()

        if not username or not password:
            return "Both username and password are required!"

        users = safe_load_users()

        if username in users and users[username]["password"] == password:
            session["user"] = username
            return redirect(url_for("select"))
        else:
            return "Invalid username or password!"
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# ----------------- NEW ROUTE -----------------
@app.route("/select", methods=["GET", "POST"])
def select():
    if "user" not in session:
        return redirect(url_for("login"))

    topics = get_topics_and_difficulties()

    if request.method == "POST":
        topic = request.form.get("topic")
        difficulty = request.form.get("difficulty")
        if not topic or not difficulty:
            return "Please select both topic and difficulty!"

        session["topic"] = topic
        session["difficulty"] = difficulty
        return redirect(url_for("index"))

    return render_template("select.html", topics=topics)

# ---------------------------------------------
@app.route("/index")
def index():
    if "user" not in session:
        return redirect(url_for("login"))
    if "topic" not in session or "difficulty" not in session:
        return redirect(url_for("select"))

    username = session["user"]
    topic = session["topic"]
    difficulty = session["difficulty"]

    return render_template("index.html", username=username, topic=topic, difficulty=difficulty)

@app.route("/get_question", methods=["POST"])
def get_question():
    data = request.json
    q_type = data.get("type", "rule")
    topic = session.get("topic", "Python")
    difficulty = session.get("difficulty", "Basic")

    if q_type == "rule":
        questions = load_rule_questions(topic, difficulty)
        if not questions:
            return jsonify({"question": f"No questions found for {topic} ({difficulty})."})
        question = random.choice(questions)
    else:
        question = get_ai_question(topic)

    return jsonify({"question": question})

@app.route("/submit_answer", methods=["POST"])
def submit_answer():
    data = request.json
    question = data.get("question")
    answer = data.get("answer")
    username = session.get("user")
    if question and answer and username:
        attempt = {"user": username, "question": question, "answer": answer}
        with open(ATTEMPTS_FILE, "a") as f:
            f.write(json.dumps(attempt) + "\n")
        return jsonify({"status": "saved"})
    return jsonify({"status": "error"})

if __name__ == "__main__":
    app.run(debug=True)
